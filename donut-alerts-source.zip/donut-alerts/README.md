# Donut Alerts (Fabric 1.21.1)

Client-side DonutSMP helper with two independent features:

1. **Auction House alerts** using the official DonutSMP public API.
2. **Orders hover history** learned locally from prices visible in the DonutSMP Orders GUI. It does not pretend an Orders API exists.

## Commands
- `/alerts` — open alert GUI
- `/alerts scan` — queue an AH scan
- `/o` — client-side shortcut that sends `/orders` to the server

## AH setup
Run `/api` on DonutSMP to obtain your API key, then open `/alerts` -> Settings and paste it. The key is saved in `config/donut-alerts.json` and is never intentionally printed to chat/logs.

Add AH alerts with a namespaced item ID such as `minecraft:bone_block`, target price, and Lowest/Highest. Lowest triggers at `price <= target`; Highest triggers at `price >= target`. Alerts re-arm only after the condition becomes false.

## Orders hover analyzer
Open the server's Orders inventory and hover listings. When the screen title contains `order`, the mod looks for a price in the tooltip and records observations per Minecraft item ID. It shows:
- green when the current observed price is at or below the median of previous observations;
- red when it is at or above the previous average;
- yellow otherwise.

Example: after observing `$450` and `$100`, the median is `$275`, so a later `$200` is shown green. History is local and capped at 50 observations/item by default.

**Important:** DonutSMP can change its Orders GUI text. If the price is not present in the tooltip or uses an unexpected format, the parser may need a small update. This build intentionally does not scrape packets or invent an Orders API.

## Build
Requirements: JDK 21.

```bash
./gradlew build
```

If the Gradle wrapper is not present, use a local Gradle installation once to run `gradle wrapper`, then `./gradlew build`.

The jar will be under `build/libs/`. Install Fabric Loader 1.21.1 + Fabric API, then place the jar in `.minecraft/mods/`.

## API implementation notes
The official API documents `GET /v1/auction/list/{page}`, Bearer authentication, `search` / `sort` request fields, and a 250 requests/minute/API-key limit. This mod groups enabled alerts by item and does two requests per unique tracked item (lowest + highest), not one request per alert. HTTP 429 applies a local backoff.
