package dev.donutalerts;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.*;
import net.minecraft.text.Text;

final class SettingsScreen extends Screen {
 private final Screen parent; private TextFieldWidget key,poll;
 SettingsScreen(Screen p){super(Text.literal("Donut Alerts Settings"));parent=p;}
 @Override protected void init(){int cx=width/2;
  key=new TextFieldWidget(textRenderer,cx-120,50,240,20,Text.literal("API key")); key.setText(DonutAlertsClient.CONFIG.apiKey); addDrawableChild(key);
  poll=new TextFieldWidget(textRenderer,cx-120,90,240,20,Text.literal("Polling seconds")); poll.setText(String.valueOf(DonutAlertsClient.CONFIG.pollingSeconds)); addDrawableChild(poll);
  addDrawableChild(ButtonWidget.builder(Text.literal("Chat: "+on(DonutAlertsClient.CONFIG.chat)),b->{DonutAlertsClient.CONFIG.chat=!DonutAlertsClient.CONFIG.chat;clearAndInit();}).dimensions(cx-120,125,115,20).build());
  addDrawableChild(ButtonWidget.builder(Text.literal("Sound: "+on(DonutAlertsClient.CONFIG.sound)),b->{DonutAlertsClient.CONFIG.sound=!DonutAlertsClient.CONFIG.sound;clearAndInit();}).dimensions(cx+5,125,115,20).build());
  addDrawableChild(ButtonWidget.builder(Text.literal("Save"),b->save()).dimensions(cx-50,165,100,20).build());
 }
 private String on(boolean b){return b?"ON":"OFF";} private void save(){DonutAlertsClient.CONFIG.apiKey=key.getText().trim();try{DonutAlertsClient.CONFIG.pollingSeconds=Math.max(5,Integer.parseInt(poll.getText()));}catch(Exception ignored){}ConfigStore.save(DonutAlertsClient.CONFIG);client.setScreen(parent);}
 @Override public void render(DrawContext c,int mx,int my,float d){super.render(c,mx,my,d);c.drawCenteredTextWithShadow(textRenderer,title,width/2,15,0xFFFFFF);c.drawTextWithShadow(textRenderer,Text.literal("API key (stored locally; never logged)"),width/2-120,38,0xAAAAAA);c.drawTextWithShadow(textRenderer,Text.literal("Polling interval seconds (min 5)"),width/2-120,78,0xAAAAAA);}
 @Override public void close(){client.setScreen(parent);}
}
