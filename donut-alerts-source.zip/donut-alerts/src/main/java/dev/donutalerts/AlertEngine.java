package dev.donutalerts;

import net.minecraft.client.MinecraftClient;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import java.util.*;
import java.util.concurrent.*;

final class AlertEngine {
 private final DonutApiClient api = new DonutApiClient();
 private final ScheduledExecutorService exec = Executors.newSingleThreadScheduledExecutor(r -> { Thread t=new Thread(r,"DonutAlerts-Scanner"); t.setDaemon(true); return t; });
 private volatile boolean scanning;
 void start(){ exec.scheduleWithFixedDelay(this::scanSafe,5,1,TimeUnit.SECONDS); }
 void stop(){ exec.shutdownNow(); }
 void scanNow(){ exec.execute(this::scanSafe); }
 private void scanSafe(){
  if(scanning) return; scanning=true;
  try {
   if(DonutAlertsClient.CONFIG.apiKey.isBlank()) return;
   long now=System.currentTimeMillis();
   if(now-DonutAlertsClient.lastScanMs < DonutAlertsClient.CONFIG.pollingSeconds*1000L) return;
   DonutAlertsClient.lastScanMs=now;
   Map<String,List<Model.Alert>> groups=new LinkedHashMap<>();
   for(Model.Alert a:DonutAlertsClient.CONFIG.alerts) if(a.enabled) groups.computeIfAbsent(a.itemId,k->new ArrayList<>()).add(a);
   for(var e:groups.entrySet()) {
    DonutAlertsClient.currentQueryItem.set(e.getKey());
    try { Model.Prices p=api.prices(e.getKey(),DonutAlertsClient.CONFIG.apiKey).join(); for(Model.Alert a:e.getValue()) evaluate(a,p); DonutAlertsClient.lastStatus="Connected"; }
    catch(Exception ex){ DonutAlertsClient.lastStatus="Error: "+root(ex).getMessage(); }
    finally { DonutAlertsClient.currentQueryItem.remove(); }
   }
  } finally { scanning=false; }
 }
 private static Throwable root(Throwable t){ while(t.getCause()!=null)t=t.getCause(); return t; }
 private void evaluate(Model.Alert a, Model.Prices p){
  Double price=a.direction==Model.Direction.LOWEST?p.lowest():p.highest(); if(price==null)return;
  boolean hit=a.direction==Model.Direction.LOWEST?price<=a.target:price>=a.target;
  if(!hit){ a.armed=true; ConfigStore.save(DonutAlertsClient.CONFIG); return; }
  long now=System.currentTimeMillis(); if(!a.armed || now-a.lastNotifyMs<DonutAlertsClient.CONFIG.cooldownSeconds*1000L)return;
  a.armed=false; a.lastNotifyMs=now; ConfigStore.save(DonutAlertsClient.CONFIG);
  MinecraftClient mc=MinecraftClient.getInstance(); mc.execute(()->{
   if(mc.player==null)return;
   String msg="[Donut Alerts] "+a.itemId+" AH "+a.direction+": $"+PriceUtil.fmt(price)+" | target $"+PriceUtil.fmt(a.target);
   if(DonutAlertsClient.CONFIG.chat) mc.player.sendMessage(Text.literal(msg).formatted(Formatting.GOLD),false);
   if(DonutAlertsClient.CONFIG.sound) mc.player.playSound(SoundEvents.BLOCK_NOTE_BLOCK_PLING.value(),1f,1f);
  });
 }
}
