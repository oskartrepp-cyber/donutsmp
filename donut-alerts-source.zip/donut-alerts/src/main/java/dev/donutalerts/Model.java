package dev.donutalerts;

import java.util.*;

final class Model {
 enum Direction { LOWEST, HIGHEST }
 static final class Alert {
  String id = UUID.randomUUID().toString();
  String itemId = "minecraft:diamond";
  double target = 1000;
  Direction direction = Direction.LOWEST;
  boolean enabled = true;
  boolean armed = true;
  long lastNotifyMs = 0;
 }
 static final class Config {
  String apiKey = "";
  int pollingSeconds = 30;
  boolean chat = true, sound = true;
  long cooldownSeconds = 30;
  List<Alert> alerts = new ArrayList<>();
  Map<String,List<Double>> orderHistory = new HashMap<>();
  int orderHistoryLimit = 50;
 }
 record Prices(Double lowest, Double highest) {}
}
