package dev.donutalerts;

import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;

final class ConfigStore {
 private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
 private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("donut-alerts.json");
 static Model.Config load() {
  try { if (Files.exists(FILE)) return GSON.fromJson(Files.readString(FILE), Model.Config.class); }
  catch (Exception ignored) {}
  return new Model.Config();
 }
 static synchronized void save(Model.Config c) {
  try { Files.createDirectories(FILE.getParent()); Files.writeString(FILE, GSON.toJson(c), StandardCharsets.UTF_8); }
  catch (Exception e) { DonutAlertsClient.LOG.warn("Could not save Donut Alerts config: {}", e.toString()); }
 }
}
