package dev.donutalerts;

import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import java.util.*;
import java.util.regex.*;

final class OrderHoverAnalyzer {
 private static final Pattern MONEY=Pattern.compile("(?i)(?:\\$|price\\s*:?\\s*\\$?)\\s*([0-9][0-9,]*(?:\\.[0-9]+)?)");
 static void register(){ ItemTooltipCallback.EVENT.register((stack,ctx,type,lines)->augment(stack,lines)); }
 private static void augment(ItemStack stack,List<Text> lines){
  MinecraftClient mc=MinecraftClient.getInstance();
  if(!(mc.currentScreen instanceof HandledScreen<?> hs) || !hs.getTitle().getString().toLowerCase(Locale.ROOT).contains("order")) return;
  Double price=parse(lines); if(price==null)return;
  String itemId=Registries.ITEM.getId(stack.getItem()).toString();
  List<Double> hist=DonutAlertsClient.CONFIG.orderHistory.computeIfAbsent(itemId,k->new ArrayList<>());
  if(hist.isEmpty()) lines.add(Text.literal("Donut history: first observation").formatted(Formatting.GRAY));
  else {
   double avg=hist.stream().mapToDouble(Double::doubleValue).average().orElse(price);
   double median=median(hist); double min=Collections.min(hist), max=Collections.max(hist);
   Formatting c=price<=median?Formatting.GREEN:(price>=avg?Formatting.RED:Formatting.YELLOW);
   String label=price<=median?"GOOD vs history":(price>=avg?"HIGH vs history":"NORMAL vs history");
   lines.add(Text.literal("Donut Orders: "+label).formatted(c));
   lines.add(Text.literal("Previous median: $"+PriceUtil.fmt(median)+" | range $"+PriceUtil.fmt(min)+"-$"+PriceUtil.fmt(max)).formatted(Formatting.DARK_GRAY));
  }
  // Avoid adding the same hovered price every frame: only record a changed observation for this item.
  String key=itemId+"@"+price; long now=System.currentTimeMillis();
  if(!key.equals(DonutAlertsClient.lastOrderObservationKey) || now-DonutAlertsClient.lastOrderObservationMs>3000){
   hist.add(price); while(hist.size()>DonutAlertsClient.CONFIG.orderHistoryLimit) hist.remove(0);
   DonutAlertsClient.lastOrderObservationKey=key; DonutAlertsClient.lastOrderObservationMs=now; ConfigStore.save(DonutAlertsClient.CONFIG);
  }
 }
 private static Double parse(List<Text> lines){ for(Text t:lines){ Matcher m=MONEY.matcher(t.getString()); if(m.find()) try{return Double.parseDouble(m.group(1).replace(",",""));}catch(Exception ignored){} } return null; }
 private static double median(List<Double> xs){ List<Double> c=new ArrayList<>(xs); Collections.sort(c); int n=c.size(); return n%2==1?c.get(n/2):(c.get(n/2-1)+c.get(n/2))/2.0; }
}
