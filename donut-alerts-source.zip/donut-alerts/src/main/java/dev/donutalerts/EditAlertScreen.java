package dev.donutalerts;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.*;
import net.minecraft.text.Text;

final class EditAlertScreen extends Screen {
 private final Screen parent; private final Model.Alert existing; private TextFieldWidget item,price; private Model.Direction dir;
 EditAlertScreen(Screen p,Model.Alert a){super(Text.literal(a==null?"Add AH Alert":"Edit AH Alert"));parent=p;existing=a;dir=a==null?Model.Direction.LOWEST:a.direction;}
 @Override protected void init(){ int cx=width/2;
  item=new TextFieldWidget(textRenderer,cx-100,45,200,20,Text.literal("Item ID")); item.setText(existing==null?"minecraft:diamond":existing.itemId); addDrawableChild(item);
  price=new TextFieldWidget(textRenderer,cx-100,80,200,20,Text.literal("Target")); price.setText(existing==null?"1000":String.valueOf(existing.target)); addDrawableChild(price);
  addDrawableChild(ButtonWidget.builder(Text.literal("Lowest"),b->{dir=Model.Direction.LOWEST;clearAndInit();}).dimensions(cx-100,115,95,20).build());
  addDrawableChild(ButtonWidget.builder(Text.literal("Highest"),b->{dir=Model.Direction.HIGHEST;clearAndInit();}).dimensions(cx+5,115,95,20).build());
  addDrawableChild(ButtonWidget.builder(Text.literal("Save"),b->save()).dimensions(cx-100,155,95,20).build());
  if(existing!=null) addDrawableChild(ButtonWidget.builder(Text.literal(existing.enabled?"Disable":"Enable"),b->{existing.enabled=!existing.enabled;ConfigStore.save(DonutAlertsClient.CONFIG);client.setScreen(parent);}).dimensions(cx+5,155,95,20).build());
  if(existing!=null) addDrawableChild(ButtonWidget.builder(Text.literal("Delete"),b->{DonutAlertsClient.CONFIG.alerts.remove(existing);ConfigStore.save(DonutAlertsClient.CONFIG);client.setScreen(parent);}).dimensions(cx-100,185,200,20).build());
 }
 private void save(){ try{double v=Double.parseDouble(price.getText().replace(",","")); if(v<0)throw new Exception(); Model.Alert a=existing==null?new Model.Alert():existing;a.itemId=item.getText().trim();a.target=v;a.direction=dir;if(existing==null)DonutAlertsClient.CONFIG.alerts.add(a);ConfigStore.save(DonutAlertsClient.CONFIG);client.setScreen(parent);}catch(Exception e){price.setText("INVALID NUMBER");} }
 @Override public void render(DrawContext c,int mx,int my,float d){super.render(c,mx,my,d);c.drawCenteredTextWithShadow(textRenderer,title,width/2,15,0xFFFFFF);c.drawTextWithShadow(textRenderer,Text.literal("Item namespaced ID"),width/2-100,33,0xAAAAAA);c.drawTextWithShadow(textRenderer,Text.literal("Target price"),width/2-100,68,0xAAAAAA);c.drawCenteredTextWithShadow(textRenderer,Text.literal("Selected: AH + "+dir),width/2,140,dir==Model.Direction.LOWEST?0x55FF55:0xFFAA00);}
 @Override public void close(){client.setScreen(parent);}
}
