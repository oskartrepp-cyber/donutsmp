package dev.donutalerts;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import org.slf4j.Logger; import org.slf4j.LoggerFactory;

public final class DonutAlertsClient implements ClientModInitializer {
 static final Logger LOG=LoggerFactory.getLogger("donutalerts");
 static Model.Config CONFIG; static final AlertEngine ENGINE=new AlertEngine();
 static volatile long lastScanMs; static volatile String lastStatus="Not scanned";
 static final ThreadLocal<String> currentQueryItem=new ThreadLocal<>();
 static volatile String lastOrderObservationKey=""; static volatile long lastOrderObservationMs;
 @Override public void onInitializeClient(){
  CONFIG=ConfigStore.load(); OrderHoverAnalyzer.register(); ENGINE.start();
  ClientLifecycleEvents.CLIENT_STOPPING.register(c->ENGINE.stop());
  ClientCommandRegistrationCallback.EVENT.register((d,a)->{
   d.register(ClientCommandManager.literal("alerts").executes(c->{ MinecraftClient.getInstance().setScreen(new AlertsScreen(null)); return 1; })
    .then(ClientCommandManager.literal("scan").executes(c->{ ENGINE.scanNow(); c.getSource().sendFeedback(Text.literal("Donut Alerts scan queued.")); return 1; })));
   d.register(ClientCommandManager.literal("o").executes(c->{
    if(MinecraftClient.getInstance().getNetworkHandler()!=null) MinecraftClient.getInstance().getNetworkHandler().sendChatCommand("orders"); return 1;
   }));
  });
 }
}
