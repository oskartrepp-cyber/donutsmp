package dev.donutalerts;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import java.util.*;

final class AlertsScreen extends Screen {
 private final Screen parent; AlertsScreen(Screen p){super(Text.literal("DonutSMP Price Alerts"));parent=p;}
 @Override protected void init(){
  int cx=width/2;
  addDrawableChild(ButtonWidget.builder(Text.literal("+ Add Alert"),b->client.setScreen(new EditAlertScreen(this,null))).dimensions(cx-150,35,100,20).build());
  addDrawableChild(ButtonWidget.builder(Text.literal("Settings"),b->client.setScreen(new SettingsScreen(this))).dimensions(cx-45,35,90,20).build());
  addDrawableChild(ButtonWidget.builder(Text.literal("Scan Now"),b->DonutAlertsClient.ENGINE.scanNow()).dimensions(cx+50,35,100,20).build());
  int y=70; for(Model.Alert a:new ArrayList<>(DonutAlertsClient.CONFIG.alerts)){
   int yy=y; String s=(a.enabled?"ON ":"OFF ")+a.itemId+"  $"+PriceUtil.fmt(a.target)+"  AH "+a.direction;
   addDrawableChild(ButtonWidget.builder(Text.literal(s),b->client.setScreen(new EditAlertScreen(this,a))).dimensions(cx-150,yy,300,20).build()); y+=24; if(y>height-50)break;
  }
  addDrawableChild(ButtonWidget.builder(Text.literal("Close"),b->close()).dimensions(cx-50,height-30,100,20).build());
 }
 @Override public void render(DrawContext c,int mx,int my,float d){super.render(c,mx,my,d);c.drawCenteredTextWithShadow(textRenderer,title,width/2,12,0xFFFFFF);c.drawTextWithShadow(textRenderer,Text.literal("API: "+DonutAlertsClient.lastStatus),10,height-18,0xAAAAAA);}
 @Override public void close(){client.setScreen(parent);}
}
