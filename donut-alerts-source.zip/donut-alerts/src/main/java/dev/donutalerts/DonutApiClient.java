package dev.donutalerts;

import com.google.gson.*;
import java.net.URI;
import java.net.http.*;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;

final class DonutApiClient {
 private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build();
 private volatile long backoffUntil = 0;

 CompletableFuture<Model.Prices> prices(String itemId, String apiKey) {
  if (apiKey == null || apiKey.isBlank()) return CompletableFuture.failedFuture(new IllegalStateException("API key not configured"));
  if (System.currentTimeMillis() < backoffUntil) return CompletableFuture.failedFuture(new IllegalStateException("Rate-limit backoff active"));
  String search = itemId.startsWith("minecraft:") ? itemId.substring(10).replace('_',' ') : itemId;
  return fetch(search, "lowest_price").thenCombine(fetch(search, "highest_price"), (lo, hi) -> new Model.Prices(lo, hi));
 }
 private CompletableFuture<Double> fetch(String search, String sort) {
  JsonObject body = new JsonObject(); body.addProperty("search", search); body.addProperty("sort", sort);
  HttpRequest req = HttpRequest.newBuilder(URI.create("https://api.donutsmp.net/v1/auction/list/1"))
   .timeout(Duration.ofSeconds(15)).header("Authorization", "Bearer " + DonutAlertsClient.CONFIG.apiKey)
   .header("Content-Type", "application/json").method("GET", HttpRequest.BodyPublishers.ofString(body.toString())).build();
  return http.sendAsync(req, HttpResponse.BodyHandlers.ofString()).thenApply(r -> {
   if (r.statusCode()==429) { backoffUntil = System.currentTimeMillis()+30_000; throw new CompletionException(new IllegalStateException("Rate limited")); }
   if (r.statusCode()==401) throw new CompletionException(new IllegalStateException("Invalid API key"));
   if (r.statusCode()/100!=2) throw new CompletionException(new IllegalStateException("HTTP "+r.statusCode()));
   JsonArray arr = JsonParser.parseString(r.body()).getAsJsonObject().getAsJsonArray("result");
   if (arr==null || arr.isEmpty()) return null;
   for (JsonElement el: arr) {
    JsonObject o=el.getAsJsonObject(), item=o.getAsJsonObject("item");
    if (item!=null && item.has("id")) {
     String id=item.get("id").getAsString();
     String wanted = DonutAlertsClient.currentQueryItem.get();
     if (wanted == null || id.equalsIgnoreCase(wanted) || ("minecraft:"+id).equalsIgnoreCase(wanted)) return o.get("price").getAsDouble();
    }
   }
   return null;
  });
 }
}
