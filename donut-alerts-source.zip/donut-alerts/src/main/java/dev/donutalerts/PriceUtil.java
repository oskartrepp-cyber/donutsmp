package dev.donutalerts;
import java.text.DecimalFormat;
final class PriceUtil { private static final DecimalFormat F=new DecimalFormat("#,##0.##"); static String fmt(double d){return F.format(d);} }
